﻿# EGISZ Proxy Reports Airflow

Проект для выгрузки данных из Firebird (`EXCHANGELOG`) в PostgreSQL DWH, оркестрации через Airflow и автоматической публикации дашбордов в Metabase.

## Что входит в проект

- ETL-модуль на Python: `src/proxy_reports_etl`
- DAG для Airflow: `airflow/dags/proxy_reports_etl_dag.py`
- Docker-сервисы для локального запуска: `db-init`, `etl-sync`, `metabase`
- Скрипты и JSON-дэшборды для автопровижининга Metabase

## Требования

- Docker Desktop (с поддержкой `docker compose`)
- PostgreSQL, доступный с хоста (по умолчанию `host.docker.internal:5432`)
- Firebird, доступный с хоста (по умолчанию `host.docker.internal/3050:proxy_egisz`)
- Для локальной сборки Python-пакета на Windows: `py` (Python Launcher)

## Настройка окружения

1. Скопируйте `.env` и заполните значения:

```env
POSTGRES_HOST=host.docker.internal
POSTGRES_PORT=5432
POSTGRES_ADMIN_USER=egisz
POSTGRES_ADMIN_PASSWORD=egisz
DWH_DB_NAME=dwh_egisz
METABASE_APP_DB_NAME=metabase_app

FB_DSN=host.docker.internal/3050:proxy_egisz
FB_USER=sysdba
FB_PASSWORD=masterkey
FB_CHARSET=WIN1251

PG_DSN=postgresql://egisz:egisz@host.docker.internal:5432/dwh_egisz
FB_SOURCE_SQL=SELECT LOGID, LOGDATE, LOGTYPE, LOGSTATE, LOGMODE, MSGID, MSGTEXT, GRPID, CREATEDATE, MODIFYDATE, REPL$ID, REPL$GRPID, LOGTEXT, METHOD, URI, ACTION, PARENTLOGID FROM EXCHANGELOG
```

2. Проверьте, что пользователь PostgreSQL имеет права на создание БД (для `db-init`).

## Сборка всех модулей

1. Сборка Python-пакета:

```powershell
py -m pip install -U build
py -m build
```

2. Сборка Docker-образов всех модулей:

```powershell
docker compose build
```

## Запуск

1. Запустите сервисы:

```powershell
docker compose up -d
```

2. Выполните ETL вручную (если нужен повторный прогон):

```powershell
docker compose run --rm etl-sync sync
```

3. Проверка Metabase:

- URL: `http://localhost:3000`
- Логин: `METABASE_ADMIN_EMAIL` (по умолчанию `admin@egisz.local`)
- Пароль: `METABASE_ADMIN_PASSWORD` (по умолчанию `egisz`)

## Полезные команды

```powershell
# Логи всех сервисов
docker compose logs -f

# Логи только ETL
docker compose logs -f etl-sync

# Остановка
docker compose down
```

## Структура

- `src/proxy_reports_etl` — ETL-код
- `airflow/dags` — DAG-файлы
- `metabase` — скрипты провижининга Metabase
- `metabase_dashboards` — JSON-дэшборды
- `scripts/ensure-databases.sh` — инициализация DWH и Metabase app DB
- `k8s` — примеры Kubernetes-манифестов
